<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>KanSannLike</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/app.css" />
         <!-- <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
              <script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-9400126028832869",
    enable_page_level_ads: true
  });
              </script>

        <script data-cfasync="false" type="text/javascript" src="https://www.predictivdisplay.com/a/display.php?r=2418211"></script>
<script data-cfasync="false" type="text/javascript" src="https://www.predictivdisplay.com/a/display.php?r=2418219"></script> -->

		<script src="js/app.js"></script>

	</head>
	<body>

		<header><h1><em>KanSannLike</em></h1>
			<p>Test your luck...<br />Raise your mobile bills...<br />Save your finances...</p>
		</header>

<!-- <script data-cfasync="false" type="text/javascript" src="https://www.predictivdisplay.com/a/display.php?r=2419967"></script> -->

<!-- <div id="SC_TBlock_654414" class="SC_TBlock">loading...</div> -->

		<div align="center">
			<form action="check.php" method="post" id="intro">
				<label for="phone">Enter your phone number.</label>
				<input type="tel" placeholder="eg. 09791234567" required pattern="^\d{11}$" id="phone" name="phone"/>
				<input type="submit" value="Go" class="btn"/>
		    </form>
		</div>

		<script>

				// if(isUnicode())
				// {
				// document.getElementsByTagName("label")[0].innerHTML="ဖုန်းနံပါတ်ထည့်ပါ";
				// }
		</script>
<!-- <script type="text/javascript">
  (sc_adv_out = window.sc_adv_out || []).push({
    id : "654414",
    domain : "n.ads3-adnow.com"
  });
</script>
<script type="text/javascript" src="//st-n.ads3-adnow.com/js/a.js"></script> -->
	</body>
</html>
